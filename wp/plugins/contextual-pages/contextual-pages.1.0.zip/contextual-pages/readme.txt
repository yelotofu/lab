=== Plugin Name ===
Contributors: caphun
Plugin Name: Contextual Pages Widget
Plugin URI:  http://yelotofu.com/labs/wp/plugins/contextual-pages
Author URI:  http://yelotofu.com
Tags: subpages, widget, pages, child pages, contextual, depth, level
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 1.0

The Contextual Pages Widget allows you to display pages in a target depth within the current context tree.

== Description ==

Use the Contextual Pages widget to add pages at a target depth as a widget.

This similar to the Pages widget except you can choose a depth and the list pages automatically confines to the current hierarchical context.


== Installation ==


1. Upload folder called `contextual-pages` to the `/wp-content/plugins/` directory or use the automatic install available by WordPress
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Simply go to Appearance -> Widgets and select Contextual Pages. Put it in your widget area and configure as desired.

== Frequently Asked Questions ==

Contact me directly

== Upgrade Notice ==

NIL

== Screenshots ==

NIL


== Changelog ==

= 1.0 =
* First release








