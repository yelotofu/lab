/*
 * jQuery UI Stepper
 *
 * Copyright (c) 2008 Ca Phun Ung <caphun at yelotofu dot com>
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://yelotofu.com/labs/jquery/UI/stepper
 *
 * Depends: 
 *	ui.core.js 
 *	jquery.mousewheel.js
 *
 */
;(function($) {

$.widget("ui.stepper", {

	init: function() {
		var self = this;
		
		var keys = {
			BACKSPACE: 8,
			TAB: 9,
			LEFT_ARROW: 37,
			UP_ARROW: 38,
			RIGHT_ARROW: 39,
			DOWN_ARROW: 40,
			PLUS: 61,
			MINUS: 109
		};
		
		// check for decimals in step size
		if (this.options.step.toString().indexOf('.') != -1) {
			var s = this.options.step.toString();
			this.setData('decimals', s.slice(s.indexOf('.')+1, s.length).length);
		}
		
		this.element.each(function(){
			var ns = $(this);
			var textbox = $('input[type="text"]', ns); // get the input textbox
			var bup = $('.ui-stepper-plus', ns); // plus button
			var bdn = $('.ui-stepper-minus', ns); // minus button
			var textboxVal = self.value(textbox.val());	
			
			if (textbox.length > 0){
				if (textboxVal == '' || isNaN(textboxVal)) {
					textbox.val(self.format(self.options.start));
					textboxVal = self.value(textbox.val());
				}
				
				// detect key presses and restrict to numeric values only
				textbox.keypress(function(e){
					var keynum = (window.event ? event.keyCode : (e.which ? e.which : null));
					keychar = String.fromCharCode(keynum);
					numcheck = /[0-9\-\.]/;
					switch (keynum) {
						case keys.BACKSPACE :
						case keys.TAB :
						case null :
							return true;
						default :
							return numcheck.test(keychar);
					}
				});
				
				// detect cursor keys
				textbox.keyup(function(e){
					var keynum = (window.event ? event.keyCode : (e.which ? e.which : null));
					switch (keynum) {
						case keys.UP_ARROW : // cursor key up (increment)
						case keys.PLUS :
							stepper(self.options.step); return true;
						case keys.DOWN_ARROW : // cursor key down (decrement)
						case keys.MINUS :
							stepper(-self.options.step); return true;
//						case keys.RIGHT_ARROW : // cursor key right (focus on first button)
//							bup.focus(); return true;
						default : return true;
					}
				});
				
				// detect when textbox loses cursor focus
				textbox.blur(function(e){
					if (this.value < self.options.min) this.value = self.options.min;
					if (this.value > self.options.max) this.value = self.options.max;
				});
				
				if (textbox.mousewheel != undefined){
					textbox.mousewheel(function(e, delta){
						if (delta > 0)
							stepper(self.options.step);
						else if (delta < 0)
							stepper(-self.options.step);
						return false;
					});
				}
				
				textbox.autocomplete = "off"; // turns off autocomplete in opera!
			}
			
			// convert button type to button to prevent form submission onclick
			if (bup.attr('type') == 'submit') {
				try {
					bup.removeAttr('type');
					bup.attr('type', 'button');
				} catch(e) {
					// IE fix
					bup.each(function(){
						this.removeAttribute('type');
						this.setAttribute('type','button');
					});
				}
			}
			bup.click(function(){stepper(self.options.step);});
			bup.keyup(function(e) {
				var keynum = (window.event ? event.keyCode : (e.which ? e.which : null));
				switch (keynum) {
					// (prev object)
					case keys.UP_ARROW :
					case keys.LEFT_ARROW :
						textbox.focus(); break;
					// (next object)
					case keys.DOWN_ARROW :
					case keys.RIGHT_ARROW :
						bdn.focus(); break;
				}
			});
			
			// convert button type to button to prevent form submission onclick
			if (bdn.attr('type') == 'submit') {
				try {
					bdn.removeAttr('type');
					bdn.attr('type', 'button');
				} catch(e) {
					// IE fix
					bdn.each(function(){
						this.removeAttribute('type');
						this.setAttribute('type','button');
					});
				}
			}
			bdn.click(function(){stepper(-self.options.step);});
			bdn.keyup(function(e){
				var keynum = (window.event ? event.keyCode : (e.which ? e.which : null));
				switch (keynum) {
					// (prev object)
					case keys.UP_ARROW :
					case keys.LEFT_ARROW :
						bup.focus(); break;
					// (next object)
					case keys.DOWN_ARROW :
					case keys.RIGHT_ARROW :
					   break;
				}
			});
			
			function stepper(val){
				if (textbox == undefined)
					return false;
				
				if (val == undefined || isNaN(val))
					val = 1;
				
				textboxVal = parseFloat(textboxVal) + parseFloat(val);
				
				if (textboxVal < self.options.min)
					textboxVal = self.options.min;
				
				if (textboxVal > self.options.max)
					textboxVal = self.options.max;
				
				textbox.val(self.format(textboxVal));
			}
		});
	},
	
	number: function(num, dec) {
		return Math.round(parseFloat(num)*Math.pow(10, dec)) / Math.pow(10, dec);
	},
	
	currency: function(num) {
		var s = this.number(num, 2).toString();
		var dot = parseInt(s).toString().length+1;
		s = s + ((s.indexOf('.') == -1) ? '.' : '') + '0000000001';
		s = s.substr(0, dot) + s.substr(dot, 2);
		return this.options.symbol + s;
	},
	
	value: function(val) {
		val = val.toString();
		return (this.options.format == 'currency') ? val.slice(this.options.symbol.length, val.length) : val;
	},
	
	format: function(val) {
		return (this.options.format == 'currency') ? this.currency(val) : this.number(val, this.options.decimals);
	}
	
});

$.ui.stepper.getter = "value";

$.ui.stepper.defaults = {
	min: 0,
	max: 10,
	step: 1,
	start: 0,
	decimals: 0,
	format: '',
	symbol: '$'
};

})(jQuery);